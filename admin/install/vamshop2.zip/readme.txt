Движок интернет-магазина VamShop.
Официальный сайт - http://vamshop.ru

Как установить - http://support.vamshop.ru/modules/smartfaq/faq.php?faqid=1