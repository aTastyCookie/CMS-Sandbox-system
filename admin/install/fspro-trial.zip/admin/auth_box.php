<?php
/*****************************************************************************\
+-----------------------------------------------------------------------------+
| Fast-Sales Pro                                                              |
| Copyright (c) 2007-2013 Fsales development group <support@fast-sales.ru>    |
| All rights reserved.                                                        |
+-----------------------------------------------------------------------------+
| PLEASE READ  THE FULL TEXT OF SOFTWARE LICENSE AGREEMENT IN THE "COPYRIGHT" |
| FILE PROVIDED WITH THIS DISTRIBUTION. THE AGREEMENT TEXT IS ALSO AVAILABLE  |
| AT THE FOLLOWING URL: http://fast-sales.ru/fsales_pro_license.html          |
|                                                                             |
| THIS  AGREEMENT  EXPRESSES  THE  TERMS  AND CONDITIONS ON WHICH YOU MAY USE |
| THIS SOFTWARE   PROGRAM   AND  ASSOCIATED  DOCUMENTATION   THAT  Fsales     |
| development group (hereinafter  referred to as "THE AUTHOR") IS FURNISHING  |
| OR MAKING AVAILABLE TO YOU WITH  THIS  AGREEMENT  (COLLECTIVELY,  THE       |
| "SOFTWARE"). PLEASE   REVIEW   THE  TERMS  AND   CONDITIONS  OF  THIS       |
| LICENSE AGREEMENT CAREFULLY   BEFORE   INSTALLING   OR  USING  THE          |
| SOFTWARE.  BY INSTALLING, COPYING   OR   OTHERWISE   USING   THE            |
| SOFTWARE,  YOU  AND  YOUR  COMPANY (COLLECTIVELY,  "YOU")  ARE  ACCEPTING   |
| AND AGREEING  TO  THE TERMS OF THIS LICENSE   AGREEMENT.   IF  YOU    ARE   |
| NOT  WILLING   TO  BE  BOUND BY THIS AGREEMENT, DO  NOT INSTALL OR USE THE  |
| SOFTWARE.  VARIOUS   COPYRIGHTS   AND OTHER   INTELLECTUAL   PROPERTY       |
| RIGHTS    PROTECT   THE   SOFTWARE.  THIS AGREEMENT IS A LICENSE AGREEMENT  |
| THAT GIVES  YOU  LIMITED  RIGHTS   TO  USE THE  SOFTWARE   AND  NOT  AN     |
| AGREEMENT  FOR SALE OR FOR  TRANSFER OF TITLE. THE AUTHOR RETAINS ALL RIGHTS|
| NOT EXPRESSLY GRANTED BY THIS AGREEMENT.                                    |
|                                                                             |
| The Initial Developers of the Original Code are Fsales development group    |
| Portions created by Fsales development group are Copyright (C) 2007-2013    |
| Fsales development group. All Rights Reserved.                              |
+-----------------------------------------------------------------------------+
\*****************************************************************************/

	define('FS_AUTH_BOX', true);

	require './setup.php';

	if (!empty($_REQUEST['act'])) {
		if ('logout' == $_REQUEST['act']) {
			unset($_SESSION['admin_info']);
			RememberMe::ClearAdmin();
			header('Location: '.BASE_URL); exit;
		} elseif ('pwd_recover' == $_REQUEST['act'] && isset($_REQUEST['email'])) {
			$email     = $_REQUEST['email'];
			$keystring = $_POST['keystring'];
			
			if (!isset($_SESSION['captcha_keystring']) || $_SESSION['captcha_keystring'] != $keystring) {
				func_msgs_append('Введенный текст не совпадает с текстом на картинке', '');
			} else {
				$user_id = Users::GetUserId($email, 'ADMIN');
				
				if ($user_id > 0) {
					$new_pwd = mb_substr(md5(CURRENT_TIMESTAMP.$email.rand()), 1, 12);
	
					$language  = 'ru';
					$from      = $CONFIG['settings']['admin_email'];
					$from_name = $CONFIG['settings']['shop_name'];
					$to        = $email;
					$subject   = $CONFIG['settings']['shop_name'].': New admin password';
					$body      = 'Для администратора, имеющего почтовый ящик <b>'.$email.'</b>, сгенерирован новый пароль: <b>'.$new_pwd.'</b>';
					
					if (!Mail::Send($language, $from, $from_name, $to, $subject, $body, $error_text)) {
						func_msgs_append($error_text, '');
					} else {
						$salt1 = Users::GenPwdSalt();
						$salt2 = Users::GenPwdSalt();
						$hash  = Users::GetPwdHash($new_pwd, $salt1, $salt2);
						
						if (!Users::SetPwdHash($user_id, $hash, $salt1, $salt2)) {
							func_msgs_append('Не удается обновить пароль администратора', '');
						} else {
							func_msgs_append('', 'Новый пароль отправлен на e-mail администратора');
						}
					}
				} else {
					func_msgs_append('Администратора с указанным e-mail не существует', '');
				}
			}
		}
	}
	
	func_msgs_process();

	$SMARTY->assign('KCAPTCHA_IMG', KCAPTCHA_PATH.'index.php?'.session_name().'='.session_id().'&rnd='.mt_rand());
	$SMARTY->display('auth_box.html');
?>