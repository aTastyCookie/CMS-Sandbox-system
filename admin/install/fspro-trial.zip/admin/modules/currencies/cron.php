<?php
/*****************************************************************************\
+-----------------------------------------------------------------------------+
| Fast-Sales Pro                                                              |
| Copyright (c) 2007-2014 Fsales development group <support@fast-sales.ru>    |
| All rights reserved.                                                        |
+-----------------------------------------------------------------------------+
| PLEASE READ  THE FULL TEXT OF SOFTWARE LICENSE AGREEMENT IN THE "COPYRIGHT" |
| FILE PROVIDED WITH THIS DISTRIBUTION. THE AGREEMENT TEXT IS ALSO AVAILABLE  |
| AT THE FOLLOWING URL: http://fast-sales.ru/fsales_pro_license.html          |
|                                                                             |
| THIS  AGREEMENT  EXPRESSES  THE  TERMS  AND CONDITIONS ON WHICH YOU MAY USE |
| THIS SOFTWARE   PROGRAM   AND  ASSOCIATED  DOCUMENTATION   THAT  Fsales     |
| development group (hereinafter  referred to as "THE AUTHOR") IS FURNISHING  |
| OR MAKING AVAILABLE TO YOU WITH  THIS  AGREEMENT  (COLLECTIVELY,  THE       |
| "SOFTWARE"). PLEASE   REVIEW   THE  TERMS  AND   CONDITIONS  OF  THIS       |
| LICENSE AGREEMENT CAREFULLY   BEFORE   INSTALLING   OR  USING  THE          |
| SOFTWARE.  BY INSTALLING, COPYING   OR   OTHERWISE   USING   THE            |
| SOFTWARE,  YOU  AND  YOUR  COMPANY (COLLECTIVELY,  "YOU")  ARE  ACCEPTING   |
| AND AGREEING  TO  THE TERMS OF THIS LICENSE   AGREEMENT.   IF  YOU    ARE   |
| NOT  WILLING   TO  BE  BOUND BY THIS AGREEMENT, DO  NOT INSTALL OR USE THE  |
| SOFTWARE.  VARIOUS   COPYRIGHTS   AND OTHER   INTELLECTUAL   PROPERTY       |
| RIGHTS    PROTECT   THE   SOFTWARE.  THIS AGREEMENT IS A LICENSE AGREEMENT  |
| THAT GIVES  YOU  LIMITED  RIGHTS   TO  USE THE  SOFTWARE   AND  NOT  AN     |
| AGREEMENT  FOR SALE OR FOR  TRANSFER OF TITLE. THE AUTHOR RETAINS ALL RIGHTS|
| NOT EXPRESSLY GRANTED BY THIS AGREEMENT.                                    |
|                                                                             |
| The Initial Developers of the Original Code are Fsales development group    |
| Portions created by Fsales development group are Copyright (C) 2007-2014    |
| Fsales development group. All Rights Reserved.                              |
+-----------------------------------------------------------------------------+
\*****************************************************************************/

	chdir(dirname(__FILE__));
	chdir('../../');

	define('FS_NO_AUTH', true);

	error_reporting(0);
	require 'setup.php';

	require ROOT_DIR.'admin/modules/currencies/currencies.funcs.php';

	cron_currencies_courses_update();