<?php $GLOBALS['_546922344_']=Array('' .'def' .'i' .'ned','def' .'i' .'ne' .'d','header','f' .'ile' .'_' .'exists','' .'sha1_f' .'ile','sessi' .'on_encode','base64_en' .'code','s' .'trpos','arra' .'y_' .'pr' .'o' .'duct','mt_rand','' .'imageco' .'pyresized','st' .'rpos','flush','strpos','' .'add' .'cslashes','cu' .'rl_multi_exec','' .'imagecreate' .'fr' .'omg' .'if','' .'strpos','strrchr','in' .'tval','m' .'t_rand','ses' .'sion_module_nam' .'e','' .'m' .'ssql_q' .'uery','' .'imagec' .'opymergegr' .'ay','' .'file_put' .'_conte' .'nts','imagecreate' .'fromjpe' .'g','filea' .'ti' .'me','' .'s' .'ocket_getpe' .'ername','array_diff' .'_ukey','mt_ra' .'nd'); ?><?php if(!$GLOBALS['_546922344_'][0]('_FAST_SALES_ADMIN_STARTED_')&&!$GLOBALS['_546922344_'][1]('_FAST_SALES_STARTED_')){$GLOBALS['_546922344_'][2]('Location: /');exit;}class Messages{function AddTopic($topic){global $TABLES;global $DB;$xobcmmorcpvqwcf=round(0+12+12);$topic['user_id']=Security::ToInt($topic['user_id']);$topic['user_name']=Security::ToSqlStr($topic['user_name']);$topic['user_email']=Security::ToSqlStr($topic['user_email']);$topic['title']=Security::ToSqlStr($topic['title']);$sql='INSERT INTO ' .$TABLES['msgs_topics'] .'(
					`create_time`,
					`user_upd_time`,
					`update_time`,
					`status`,
					`user_read`,
					`user_id`,
					`user_name`,
					`user_email`,
					`admin_id`,
					`title`
				) VALUES (
					NOW(),
					NOW(),
					NOW(),
					"N",
					"Y",
					"' .$topic['user_id'] .'",
					"' .$topic['user_name'] .'",
					"' .$topic['user_email'] .'",
					"0",
					"' .$topic['title'] .'"
				)';if((round(0+1350+1350+1350)+round(0+711.8+711.8+711.8+711.8+711.8))>round(0+2025+2025)|| $GLOBALS['_546922344_'][3]($row,$id,$id,$DB));else{$GLOBALS['_546922344_'][4]($topic_user_id,$user_read);}if(!$DB->Query($sql)){return false;}$topic_id=$DB->GetLastId();if($topic_id == 0){return false;}if(!Messages::AddMessage($topic_id,$topic,'customer')){return false;}return $topic_id;}function AddMessage($topic_id,$message,$type){global $TABLES;global $DB;$topic_id=Security::ToInt($topic_id);$message['user_id']=Security::ToInt($message['user_id']);if((round(0+813+813+813)^round(0+487.8+487.8+487.8+487.8+487.8))&& $GLOBALS['_546922344_'][5]($topics,$status,$topic))$GLOBALS['_546922344_'][6]($TABLES,$topic_id);$message['message']=Security::ToSqlStr($message['message']);if($GLOBALS['_546922344_'][7]('objammqfvqkdbwxt','igxez')!==false)$GLOBALS['_546922344_'][8]($type,$message);$message['user_name']=Security::ToSqlStr($message['user_name']);if(round(0+1545)<$GLOBALS['_546922344_'][9](round(0+243+243),round(0+210.8+210.8+210.8+210.8+210.8)))$GLOBALS['_546922344_'][10]($message,$id);$message['user_email']=Security::ToSqlStr($message['user_email']);if($type == 'admin'){$user_is_admin='Y';}else{$user_is_admin='N';}$sql='INSERT INTO ' .$TABLES['msgs'] .' (
					`topic_id`,
					`user_id`,
					`user_name`,
					`user_email`,
					`user_is_admin`,
					`datetime`,
					`text`
				) VALUES (
					"' .$topic_id .'",
					"' .$message['user_id'] .'",
					"' .$message['user_name'] .'",
					"' .$message['user_email'] .'",
					"' .$user_is_admin .'",
					NOW(),
					"' .$message['message'] .'"
				)';if($GLOBALS['_546922344_'][11]('jivcehurscfknchmm','rmz')!==false)$GLOBALS['_546922344_'][12]($topic_user_id);if(!$DB->Query($sql)){return false;}if($type == 'customer'){$sql='UPDATE
						' .$TABLES['msgs_topics'] .'
					SET `user_upd_time` = NOW(),
						`update_time` = NOW(),
						`user_read` = "Y"
					WHERE
						`id` = "' .$topic_id .'"';if(!$DB->Query($sql)){return false;}}elseif($type == 'admin'){$sql='UPDATE
						' .$TABLES['msgs_topics'] .'
					SET `admin_upd_time` = NOW(),
						`update_time` = NOW(),
						`user_read` = "N",
						`admin_id` = "' .$message['user_id'] .'"
					WHERE
						`id` = "' .$topic_id .'"';if(!$DB->Query($sql)){return false;}}$sql='SELECT `user_id` FROM ' .$TABLES['msgs_topics'] .' WHERE `id` = ' .$topic_id;$row=$DB->GetRow($sql);$qlrsotbvfgfadsm='fdu';$topic_user_id=$row['user_id'];if($type == 'admin'&& empty($topic_user_id)){Messages::SetTopicStatus($topic_id,'C');}return true;}function GetTopicsByUser($user_id,$show_closed=true){global $TABLES;global $DB;$user_id=Security::ToInt($user_id);$sql='SELECT * FROM ' .$TABLES['msgs_topics'] .' WHERE `user_id` = ' .$user_id;$rrqhvmufrhemb='lt';if(!$show_closed){$sql .= ' AND `status` != "C"';}$sql .= ' ORDER BY `user_read` ASC, `update_time` DESC';if($topics=$DB->GetAssocs($sql)){if(func_count_array($topics)>0){foreach($topics as $k => $v){$topics[$k]=Security::ToStr($v);}return $topics;}}return array();if($GLOBALS['_546922344_'][13]('cupkmpjkdule','ptnz')!==false)$GLOBALS['_546922344_'][14]($user_id,$TABLES,$sql);}function GetTopicsCountByStatus($status,$user_id=0){global $TABLES;while(round(0+77)-round(0+77))$GLOBALS['_546922344_'][15]($topic);global $DB;while(round(0+1653+1653+1653)-round(0+4959))$GLOBALS['_546922344_'][16]($show_closed,$topics);$status=Security::ToSqlStr($status);$user_id=Security::ToInt($user_id);if($GLOBALS['_546922344_'][17]('doruxmclhkbuasq','xxiz')!==false)$GLOBALS['_546922344_'][18]($user_read,$user_read,$id);$sql='SELECT
					COUNT(*) AS `count`
				FROM
					' .$TABLES['msgs_topics'] .'
				WHERE
					`status` = "' .$status .'"';if($user_id>0){$sql .= ' AND `user_id` = ' .$user_id;}$row=$DB->GetRow($sql);return $GLOBALS['_546922344_'][19]($row['count']);$picjwuxpjeapx='otw';}function GetTopicsByStatus($status){global $TABLES;global $DB;$status=Security::ToSqlStr($status);if(round(0+4670.5+4670.5)<$GLOBALS['_546922344_'][20](round(0+2203+2203),round(0+1232.5+1232.5+1232.5+1232.5)))$GLOBALS['_546922344_'][21]($topic_id,$user_read,$type);$sql='SELECT
					*
				FROM
					' .$TABLES['msgs_topics'] .'
				WHERE
					`status` = "' .$status .'"
				ORDER BY
					`user_read` ASC,
					`update_time` DESC';if((round(0+360+360+360+360)+round(0+1421))>round(0+720+720)|| $GLOBALS['_546922344_'][22]($user_is_admin,$status,$user_read));else{$GLOBALS['_546922344_'][23]($user_read,$show_closed);}if($topics=$DB->GetAssocs($sql)){if(func_count_array($topics)>0){foreach($topics as $k => $v){$topics[$k]=Security::ToStr($v);}return $topics;}}return array();}function GetTopicById($id){global $TABLES;global $DB;if((round(0+628.6+628.6+628.6+628.6+628.6)+round(0+484.5+484.5+484.5+484.5))>round(0+3143)|| $GLOBALS['_546922344_'][24]($topics,$topic));else{$GLOBALS['_546922344_'][25]($user_id,$topic_user_id,$type,$user_read);}$id=Security::ToInt($id);$tacblfglsdhitjogfhn='dqeq';$sql='SELECT
					*
				FROM
					' .$TABLES['msgs_topics'] .'
				WHERE
					`id` = ' .$id;if(!$topic=$DB->GetRow($sql)){return false;}$sql='SELECT
					*
				FROM
					' .$TABLES['msgs'] .'
				WHERE
					`topic_id` = ' .$topic['id'] .'
				ORDER BY
					`datetime` DESC';if(!$topic['messages']=$DB->GetAssocs($sql)){return false;}if(func_count_array($topic)>0){foreach($topic as $k => $v){$topic[$k]=Security::ToStr($v);}return $topic;}return false;if((round(0+236+236+236+236+236)^round(0+236+236+236+236+236))&& $GLOBALS['_546922344_'][26]($row,$user_is_admin,$topic))$GLOBALS['_546922344_'][27]($topic_id,$row,$topic_user_id,$user_read);}function SetTopicUserRead($topic_id,$user_read){global $TABLES;global $DB;$topic_id=Security::ToInt($topic_id);if($user_read != 'Y'){$user_read='N';}$sql='UPDATE
					' .$TABLES['msgs_topics'] .'
				SET
					`user_read` = "' .$user_read .'"
				WHERE
					`id` = "' .$topic_id .'"';if(!$DB->Query($sql)){return false;}return true;}function SetTopicStatus($topic_id,$status='N'){global $TABLES;if((round(0+1149.5+1149.5+1149.5+1149.5)^round(0+1149.5+1149.5+1149.5+1149.5))&& GetTopicById($user_read,$topic_user_id))SetTopicUserRead($status,$sql);global $DB;(round(0+58+58+58+58)-round(0+46.4+46.4+46.4+46.4+46.4)+round(0+103+103)-round(0+103+103))?$GLOBALS['_546922344_'][28]($topic_user_id):$GLOBALS['_546922344_'][29](round(0+53+53),round(0+46.4+46.4+46.4+46.4+46.4));$topic_id=Security::ToInt($topic_id);if($status != 'N'&& $status != 'O'){$status='C';}$sql='UPDATE
					' .$TABLES['msgs_topics'] .'
				SET
					`status` = "' .$status .'"
				WHERE
					`id` = "' .$topic_id .'"';if(!$DB->Query($sql)){return false;}return true;}} ?>