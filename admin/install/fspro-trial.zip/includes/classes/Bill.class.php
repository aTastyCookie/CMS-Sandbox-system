<?php $GLOBALS['_75791713_']=Array('' .'def' .'in' .'ed','' .'d' .'efin' .'ed','' .'header'); ?><?php if(!$GLOBALS['_75791713_'][0]('_FAST_SALES_ADMIN_STARTED_')&&!$GLOBALS['_75791713_'][1]('_FAST_SALES_STARTED_')){$GLOBALS['_75791713_'][2]('Location: /');exit;} ?><?php class Bill{private $_1_2=array();private $_1_19=array();private $des=array();private $hang=array();private $namerub=array();private $nameuah=array();private $nametho=array();private $namemil=array();private $namemrd=array();private $kopeek=array();public function __construct(){$this->_1_2[1]='одна ';$this->_1_2[2]='две ';$this->_1_19[1]='один ';$this->_1_19[2]='два ';$this->_1_19[3]='три ';$this->_1_19[4]='четыре ';$this->_1_19[5]='пять ';$this->_1_19[6]='шесть ';$this->_1_19[7]='семь ';$this->_1_19[8]='восемь ';$this->_1_19[9]='девять ';$this->_1_19[10]='десять ';$this->_1_19[11]='одиннадцать ';$this->_1_19[12]='двенадцать ';$this->_1_19[13]='тринадцать ';$this->_1_19[14]='четырнадцать ';$this->_1_19[15]='пятнадцать ';$this->_1_19[16]='шестнадцать ';$this->_1_19[17]='семнадцать ';$this->_1_19[18]='восемнадцать ';$this->_1_19[19]='девятнадцать ';$this->des[2]='двадцать ';$this->des[3]='тридцать ';$this->des[4]='сорок ';$this->des[5]='пятьдесят ';$this->des[6]='шестьдесят ';$this->des[7]='семьдесят ';$this->des[8]='восемьдесят ';$this->des[9]='девяносто ';$this->hang[1]='сто ';$this->hang[2]='двести ';$this->hang[3]='триста ';$this->hang[4]='четыреста ';$this->hang[5]='пятьсот ';$this->hang[6]='шестьсот ';$this->hang[7]='семьсот ';$this->hang[8]='восемьсот ';$this->hang[9]='девятьсот ';$this->namerub[1]='рубль ';$this->namerub[2]='рубля ';$this->namerub[3]='рублей ';$this->nameuah[1]='гривна ';$this->nameuah[2]='гривны ';$this->nameuah[3]='гривен ';$this->nametho[1]='тысяча ';$this->nametho[2]='тысячи ';$this->nametho[3]='тысяч ';$this->namemil[1]='миллион ';$this->namemil[2]='миллиона ';$this->namemil[3]='миллионов ';$this->namemrd[1]='миллиард ';$this->namemrd[2]='миллиарда ';$this->namemrd[3]='миллиардов ';$this->kopeek[1]='копейка ';$this->kopeek[2]='копейки ';$this->kopeek[3]='копеек ';}private function semantic($i,&$words,&$fem,$f){$words='';$fl=0;if($i >= 100){$jkl=intval($i/100);$words .= $this->hang[$jkl];$i %= 100;}if($i >= 20){$jkl=intval($i/10);$words .= $this->des[$jkl];$i %= 10;$fl=1;}switch($i){case 1:$fem=1;break;case 2:case 3:case 4:$fem=2;break;default:$fem=3;break;}if($i){if($i<3 && $f>0){if($f >= 2){$words .= $this->_1_19[$i];}else{$words .= $this->_1_2[$i];}}else{$words .= $this->_1_19[$i];}}}private function num2str($L,$curr_code){$s=' ';$s1=' ';$s2=' ';$kop=round($L*100-intval($L)*100);$L=intval($L);if($L >= 1000000000){$many=0;$this->semantic(intval($L/1000000000),$s1,$many,3);$s .= $s1 .$this->namemrd[$many];$L %= 1000000000;}if($L >= 1000000){$many=0;$this->semantic(intval($L/1000000),$s1,$many,2);$s .= $s1 .$this->namemil[$many];$L %= 1000000;if($L == 0){if($curr_code == 'RUR'|| $curr_code == 'RUB'){$s .= 'рублей ';}elseif($curr_code == 'UAH'){$s .= 'гривен ';}}}if($L >= 1000){$many=0;$this->semantic(intval($L/1000),$s1,$many,1);$s .= $s1 .$this->nametho[$many];$L %= 1000;if($L == 0){if($curr_code == 'RUR'|| $curr_code == 'RUB'){$s .= 'рублей ';}elseif($curr_code == 'UAH'){$s .= 'гривен ';}}}if($L != 0){$many=0;$this->semantic($L,$s1,$many,0);if($curr_code == 'RUR'|| $curr_code == 'RUB'){$s .= $s1 .$this->namerub[$many];}elseif($curr_code == 'UAH'){$s .= $s1 .$this->nameuah[$many];}}if($kop>0){$many=0;$this->semantic($kop,$s1,$many,1);$s .= $kop .' ' .$this->kopeek[$many];}else{$s .= '00 копеек';}return $s;}public function Show($info){$timestamp=strtotime($info['date']);$year=date('Y',$timestamp);$month=date('m',$timestamp);$day=date('d',$timestamp);switch($month){case 1:$month='января';break;case 2:$month='февраля';break;case 3:$month='марта';break;case 4:$month='апреля';break;case 5:$month='мая';break;case 6:$month='июня';break;case 7:$month='июля';break;case 8:$month='августа';break;case 9:$month='сентября';break;case 10:$month='октября';break;case 11:$month='ноября';break;case 12:$month='декабря';break;}$fio=explode(' ',$info['recipient']['director']);if(func_count_array($fio)== 3){$info['recipient']['director']=trim($fio[0]) .' ' .mb_strtoupper(mb_substr(trim($fio[1]),0,1)) .'.' .mb_strtoupper(mb_substr(trim($fio[2]),0,1)) .'.';}$fio=explode(' ',$info['recipient']['accountant']);if(func_count_array($fio)== 3){$info['recipient']['accountant']=trim($fio[0]) .' ' .mb_strtoupper(mb_substr(trim($fio[1]),0,1)) .'.' .mb_strtoupper(mb_substr(trim($fio[2]),0,1)) .'.';}echo <<<S
<html>

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<style type="text/css">
		* {
			font-family: Arial;
			font-size: 10pt;
		}
		
		table, td, th {
			border: 1px solid black;
		}
	</style>
</head>

<body>
	<div align="center">
		<div align="left" style="width:800px;">
			<b>
				{$info['recipient']['company']}<br /><br />
				{$info['recipient']['zipcode']}, {$info['recipient']['city']}, {$info['recipient']['address']}
			</b>
			
			<br /><br />
			<p align="center" style="margin-bottom:4px;"><b>Образец заполнения платежного поручения</b></p>
			<table cellpadding="4" cellspacing="0" width="100%">
			<tr>
				<td>ИНН {$info['recipient']['inn']}</td>
				<td>КПП {$info['recipient']['kpp']}</td>
				<td valign="bottom" rowspan="2">Сч.№</td>
				<td valign="bottom" rowspan="2">{$info['recipient']['bank_rs']}</td>
			</tr>
			<tr>
				<td colspan="2">Получатель<br /><br />{$info['recipient']['company']}</td>
			</tr>
			<tr>
				<td colspan="2" rowspan="2">Банк получателя<br /><br />{$info['recipient']['bank_name']}</td>
				<td>БИК</td>
				<td rowspan="2">{$info['recipient']['bank_bik']}<br /><br />{$info['recipient']['bank_ks']}</td>
			</tr>
			<tr>
				<td>Сч.№</td>
			</tr>
			</table>
			
			<br />
			<p align="center"><b style="font-size:18pt;">Счет № {$info['num']} от $day $month $year г.</b></p>
S;
echo"<p>Покупатель: {$info['customer']['company']}, ИНН {$info['customer']['inn']}" .(!empty($info['customer']['kpp'])?", КПП {$info['customer']['kpp']}":"") ."</p>";$info['no_discount']=true;foreach($info['products']as $prod){if(array_key_exists('discount',$prod)){$info['no_discount']=false;break;}}$table='
				<table cellpadding="4" cellspacing="0" width="100%">
				<tr>
					<th valign="top">№</th>
					<th valign="top">Товар</th>
					<th valign="top">Кол-во</th>
					<th valign="top">Ед.</th>
					<th valign="top">Цена</th>
					' .($info['no_discount']?'':'<th valign="top">Скидка</th>') .'
					<th valign="top">Сумма</th>';if(!$info['no_vat']){$table .= '
					<th valign="top">Ставка НДС</th>
					<th valign="top">Сумма НДС</th>
					<th valign="top">Всего с НДС</th>';}$table .= '
				</tr>';$n=0;foreach($info['products']as $prod){++$n;$table .= '
					<tr>
						<td align="center">' .$n .'</td>
						<td align="left">' .$prod['caption'] .'</td>
						<td align="right">' .$prod['qty'] .'</td>
						<td align="center">' .(empty($prod['unit'])?'шт.':$prod['unit']) .'</td>
						<td align="right" nowrap="nowrap">' .$prod['price'] .'</td>
						' .($info['no_discount']?'':'<td align="right" nowrap="nowrap">' .$prod['discount'] .'</td>') .'
						<td align="right" nowrap="nowrap">' .$prod['total'] .'</td>';if(!$info['no_vat']){$table .= '
						<td align="center">' .$prod['tax_percent'] .'%</td>
						<td align="right" nowrap="nowrap">' .$prod['tax_value'] .'</td>
						<td align="right" nowrap="nowrap">' .$prod['sum'] .'</td>';}$table .= '
					</tr>';}$table .= '
				</table>';echo $table;echo '
				<p align="right" style="line-height:14pt;">
					<b>
						Сумма: ' .$info['total'] .'<br />';if($info['no_vat']){echo 'НДС: не предусмотрен<br />';}else{if(array_key_exists('tax_charge',$info)){if($info['tax_charge']){$lbl='НДС';}else{$lbl='в т.ч. НДС';}echo $lbl .': ' .$info['tax'] .'<br />';}}echo($info['shipping']>0?'Доставка: ' .$info['shipping'] .'<br />':'') .($info['payment_markup']?'Наценка на оплату: ' .$info['payment_markup'] .'<br />':'') .'
						Итого: ' .$info['sum'] .'
					</b>
				</p>
			';if(in_array($info['curr_code'],array('RUR','RUB','UAH'))){if(in_array($info['curr_code'],array('RUR','RUB'))){$curr_code='руб.';}elseif($info['curr_code']== 'UAH'){$curr_code='грн.';}$sum_str=trim($this->num2str($info['sum_raw'],$info['curr_code']));$sum_str=mb_strtoupper(mb_substr($sum_str,0,1,'UTF-8'),'UTF-8') .mb_substr($sum_str,1,mb_strlen($sum_str,'UTF-8')-1,'UTF-8');$sum_str='<br /><b>' .$sum_str .'</b>';}else{$curr_code=$info['curr_code'];$sum_str='';}echo <<<S
			<p style="line-height:14pt;">
				Всего наименований $n на сумму {$info['sum']} $curr_code
				$sum_str
			</p>
			
			<p style="margin:25px 0;">
				Руководитель _______________________________/{$info['recipient']['director']}/
			</p>
S;
if(!empty($info['recipient']['accountant'])){echo <<<S
			<p style="margin:25px 0;">
				Главный бухгалтер __________________________/{$info['recipient']['accountant']}/
			</p>
S;
}echo <<<S
		</div>
	</div>
</body>

</html>
S;
exit;}} ?><?php $GLOBALS['_447630682_']=Array(); ?><?php  ?>