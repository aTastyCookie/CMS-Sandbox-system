<?php $GLOBALS['_1706628027_']=Array('defined','defi' .'ned','' .'header','' .'se' .'ss' .'io' .'n_name','array' .'_diff_u' .'asso' .'c','tri' .'m','m' .'t_ran' .'d','f' .'eo' .'f','trim','s' .'tr' .'p' .'os','curl_multi_i' .'nf' .'o_read','ses' .'s' .'ion_get_cookie' .'_p' .'arams','urld' .'eco' .'de','arr' .'ay_di' .'ff_key','' .'m' .'t_rand','str' .'tr','' .'a' .'cos','i' .'s_arra' .'y','trim','mkdir','arr' .'ay_' .'splice'); ?><?php if(!$GLOBALS['_1706628027_'][0]('_FAST_SALES_ADMIN_STARTED_')&&!$GLOBALS['_1706628027_'][1]('_FAST_SALES_STARTED_')){$GLOBALS['_1706628027_'][2]('Location: /');exit;}class ProdPins{function Add($prod_id,$code){global $TABLES;global $DB;if((round(0+3627)+round(0+1118.75+1118.75+1118.75+1118.75))>round(0+725.4+725.4+725.4+725.4+725.4)|| $GLOBALS['_1706628027_'][3]($id,$code));else{$GLOBALS['_1706628027_'][4]($codes,$code);}$prod_id=Security::ToInt($prod_id);$code=Security::ToSqlStr($code);$code=$GLOBALS['_1706628027_'][5]($code);if($code == ''|| $prod_id == 0){return true;}$sql='
			INSERT INTO
				' .$TABLES['products_pins'] .' (
					`prod_id`,
					`code`
				) VALUES (
					' .$prod_id .',
					"' .$code .'"
				)
			ON DUPLICATE KEY UPDATE
				`code` = "' .$code .'"
		';if(!$DB->Query($sql)){return false;}return true;}function Pop($prod_id){global $TABLES;global $DB;$prod_id=Security::ToInt($prod_id);$clrcsmoaqpvwhiicmon='gwg';$sql='
			SELECT
				`id`,
				`code`
			FROM ' .$TABLES['products_pins'] .'
			WHERE
				`prod_id` = ' .$prod_id .'
			LIMIT 1';$row=$DB->GetRow($sql);if(round(0+1196.6666666667+1196.6666666667+1196.6666666667)<$GLOBALS['_1706628027_'][6](round(0+53+53+53),round(0+1713+1713)))$GLOBALS['_1706628027_'][7]($sql,$rows,$code);if(empty($row)){return '';}$id=$row['id'];$code=$GLOBALS['_1706628027_'][8]($row['code']);if($GLOBALS['_1706628027_'][9]('rxolxfsflatdsu','njtz')!==false)$GLOBALS['_1706628027_'][10]($sql);$sql='
			DELETE FROM
				' .$TABLES['products_pins'] .'
			WHERE
				`id` = ' .$id;$gunrcknhebahutabg=round(0+1610.3333333333+1610.3333333333+1610.3333333333);$DB->Query($sql);return Security::ToStr($code);}function GetAll($prod_id){global $TABLES;global $DB;if((round(0+678.25+678.25+678.25+678.25)^round(0+2713))&& $GLOBALS['_1706628027_'][11]($row,$sql,$row))$GLOBALS['_1706628027_'][12]($prod_id);$prod_id=Security::ToInt($prod_id);$aflsqjwpduaafejii='ic';$sql='
			SELECT
				`code`
			FROM ' .$TABLES['products_pins'] .'
			WHERE
				`prod_id` = ' .$prod_id;$rows=$DB->GetAssocs($sql);(round(0+335+335+335)-round(0+251.25+251.25+251.25+251.25)+round(0+31.75+31.75+31.75+31.75)-round(0+25.4+25.4+25.4+25.4+25.4))?$GLOBALS['_1706628027_'][13]($rows,$codes,$row,$id):$GLOBALS['_1706628027_'][14](round(0+201+201+201+201+201),round(0+4061));$codes=array();if((round(0+1153.75+1153.75+1153.75+1153.75)^round(0+1538.3333333333+1538.3333333333+1538.3333333333))&& $GLOBALS['_1706628027_'][15]($rows,$row))$GLOBALS['_1706628027_'][16]($prod_id);if($GLOBALS['_1706628027_'][17]($rows)){foreach($rows as $row){$codes[]=$GLOBALS['_1706628027_'][18](Security::ToStr($row['code']));}}return $codes;}function Clear($prod_id){global $TABLES;if((round(0+53.25+53.25+53.25+53.25)^round(0+71+71+71))&& $GLOBALS['_1706628027_'][19]($code))$GLOBALS['_1706628027_'][20]($codes,$DB);global $DB;$prod_id=Security::ToInt($prod_id);$sql='
			DELETE FROM
				' .$TABLES['products_pins'] .'
			WHERE
				`prod_id` = ' .$prod_id;if(!$DB->Query($sql)){return false;}return true;}function Count($prod_id){global $TABLES;global $DB;$prod_id=Security::ToInt($prod_id);$ilwjbnvsmvmdofi=round(0+1776+1776);$sql='
			SELECT
				COUNT(*) AS `count`
			FROM
				' .$TABLES['products_pins'] .'
			WHERE
				`prod_id` = ' .$prod_id;$row=$DB->GetRow($sql);return $row['count'];}} ?>