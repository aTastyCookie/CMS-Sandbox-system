<?php
# KCAPTCHA configuration file

$alphabet = "0123456789abcdefghijklmnopqrstuvwxyz"; # do not change without changing font files!

# symbols used to draw CAPTCHA
if ($_SESSION['CAPTCHA_SETTINGS']['only_digits']) {
	$allowed_symbols = '0123456789'; #digits
} else {
	$allowed_symbols = '23456789abcdeghkmnpqsuvxyz'; #alphabet without similar symbols (o=0, 1=l, i=j, t=f)
}

# folder with fonts
$fontsdir = 'fonts';

# CAPTCHA image size
if ($_SESSION['CAPTCHA_SETTINGS']['img_width'] > 0 && $_SESSION['CAPTCHA_SETTINGS']['img_width'] > $_SESSION['CAPTCHA_SETTINGS']['img_height']) {
	$width = $_SESSION['CAPTCHA_SETTINGS']['img_width'];
} else {
	$width = 90;
}
if ($_SESSION['CAPTCHA_SETTINGS']['img_height'] > 0 && $_SESSION['CAPTCHA_SETTINGS']['img_height'] < $width) {
	$height = $_SESSION['CAPTCHA_SETTINGS']['img_height'];
} else {
	$height = 45;
}

# CAPTCHA string length
$length = 4;

# symbol's vertical fluctuation amplitude divided by 2
$fluctuation_amplitude = 0;
#noise
//$white_noise_density=0; // no white noise
$white_noise_density=1/6;
//$black_noise_density=0; // no black noise
$black_noise_density=1/30;

# increase safety by prevention of spaces between symbols
$no_spaces = false;

# show credits
$show_credits = false; # set to false to remove credits line. Credits adds 12 pixels to image height
$credits = 'www.captcha.ru'; # if empty, HTTP_HOST will be shown

# CAPTCHA image colors (RGB, 0-255)
$foreground_color = array(78, 78, 78);
//$background_color = array(220, 230, 255);
//$foreground_color = array(mt_rand(0,100), mt_rand(0,100), mt_rand(0,100));
$background_color = array(255, 255, 255);

# JPEG quality of CAPTCHA image (bigger is better quality, but larger file size)
$jpeg_quality = 50;
?>