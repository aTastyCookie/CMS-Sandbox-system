<?php
$_lang["Static file path"] = 'Привязанный файл';
