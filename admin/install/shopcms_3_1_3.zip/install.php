<?php
#####################################
# ShopCMS: ������ ��������-��������
# Copyright (c) by ADGroup
# http://shopcms.ru
#####################################

include("core/config/init.php");
header ("Content-Type: text/html; charset=windows-1251");
session_set_cookie_params(33600);
session_start();
if ( isset ( $_COOKIE["PHPSESSID"] ))
    setcookie("PHPSESSID", $_COOKIE["PHPSESSID"], time() + 33600);
if ( !isset ( $_GET["check"] )) {

        echo '<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<style type="text/css">
html,body,form,p {padding: 0px; margin: 0px; }
html, body {background-color: white;}
body{text-align: left; font-size: 70%; font-family: Tahoma, Arial, Verdana; color: #000000;}
select, input, div, span, font, textarea {font-size: 100%; font-family: Tahoma, Arial, Verdana;}
table.adn {border: none; border-collapse: collapse; width: 100%;}
table.adnh {border: none; border-collapse: collapse; width: 100%; height: 100%;}
table.adw {border: none; border-collapse: collapse;}
a img, img{border: none;}
td{padding: 0px; vertical-align: top; text-align: left;}
.mid, tr.mid td{vertical-align: middle;}
.bot{vertical-align: bottom;}
.fil{overflow: hidden; height: 7px; width: 100%;}
.fil2{overflow: hidden; height: 16px; width: 100%;}
.arc{font-family: Arial, Tahoma, Verdana;}
.upc{text-transform: uppercase;}
.vright{text-align: right;}
.vleft{text-align: left;}
.vcent{text-align: center;}
a {color: #000000; text-decoration: underline;}
a:hover {color: #000000; text-decoration: none;}
.cattop {padding: 8px 16px;}

.clear {clear: both;}
#wrapper {min-height: 100%; height: auto !important; height: 100%; margin: 0 auto -76px; width: 100%;}
#container {width: 100%;}
#content {width: 100%; float: left;}
#center {margin: 0px 216px;}
#left {float: left; width: 216px; margin-left: -100%;}
#right {float: left; width: 216px; margin-left: -216px;}
.footer, .push {height: 76px;}
.footer{margin: 0px auto;}

.error{color: #ff6600;}
</style>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1251">
<link rel="icon" href="data/admin/favicon.ico" type="image/x-icon">
<link rel="shortcut icon" href="data/admin/favicon.ico" type="image/x-icon">
<title>��������� ShopCMS</title>
<script type="text/javascript">
function random_char(charlist)
{
        var now = new Date();
        var seed = now.getSeconds();
        var num = Math.floor(Math.random(seed) * charlist.length);
        return charlist.charAt(num);
}

function random_pass()
{
        var length = 4;
        var chars = "abcdefghijklmnopqrstuvwxyz";

        var pass = "";
        var i=0;

        for (i=0; i<length; i++)
        {
                pass = pass + random_char(chars);
        }
        return pass;
}
function setCookie(name, value, expires, path, domain, secure) {
        var exp = new Date();
        var oneMonthFromNow = exp.getTime() + (100*24*60*60*1000);
        exp.setTime (oneMonthFromNow);
        var curCookie = name + "=" + escape(value) + ((expires) ? "; expires=" + exp.toGMTString() : "") + ((path) ? "; path=" + path : "") + ((domain) ? "; domain=" + domain : "") + ((secure) ? "; secure" : "");
        if ( (name + "=" + escape(value)).length <= 4000) document.cookie = curCookie;
}
function randomPass()
{
        document.getElementById("install_prefix_x").value = random_pass()+ "_";
}
function doreset()
{
        if(document.getElementById("sbutton").disabled == true){
	        document.getElementById("sbutton").disabled=false;
	        document.getElementById("sbutton").value="��������� ���������";
            document.getElementById("dataload").innerHTML = "<span style=\'color: red\'><b>�������� ��������� ������ � �������� ���������.<\/b> ���������� � ������ ����������� ���������.<\/span>";
        }
}
function doLoad() {
        JsHttpRequest.query(
            "install.php", 
            {
                "next": "yes",
				"connect": "yes",
				"_databaseHost": document.getElementById("_databaseHost").value,
				"install_prefix_x": document.getElementById("install_prefix_x").value,
				"_databaseUsername": document.getElementById("_databaseUsername").value,
				"_databasePassword": document.getElementById("_databasePassword").value,
				"_databaseName": document.getElementById("_databaseName").value,
				"adminLogin": document.getElementById("adminLogin").value,
				"adminPassword": document.getElementById("adminPassword").value
            },
            // Function is called when an answer arrives.
            function(result, errors) {
                if(result) doinstall(result);
            },
            true  // do not caching
        );
}

function doinstall(req) {
        
	        document.getElementById("sbutton").disabled=false;
	        document.getElementById("sbutton").value="��������� ���������";
            document.getElementById("dataload").innerHTML = req["result"];
            setCookie(req["session_name"],req["session_id"],"1","/");
}';


        echo '</script>
</head>
<body style="padding: 0px 20px 0px 20px;"><br><div style="font-size: 26px;">��������� ShopCMS 3.1.3</div><br><br>';

        echo "<table class=adw><tr><td align=left valign=top><b>�������� ����� PHP</b><br><br>";
        $sp1 = ( ini_get('session.use_trans_sid') == 1 || strtolower(ini_get('session.use_trans_sid')) == 'on' ) ? 0 : 1;
        if ( $sp1 == 1 )
            echo "session.use_trans_sid - <span style='color: green'>OK</span><br>";
        else
            echo "session.use_trans_sid - <span style='color: red'>ERROR</span><br>";
        $sp2 = ( ini_get('session.use_cookies') == 1 || strtolower(ini_get('session.use_cookies')) == 'on' ) ? 1 : 0;
        if ( $sp2 == 1 )
            echo "session.use_cookies - <span style='color: green'>OK</span><br>";
        else
            echo "session.use_cookies - <span style='color: red'>ERROR</span><br>";
        $sp3 = ( ini_get('session.use_only_cookies') == 1 || strtolower(ini_get('session.use_only_cookies')) == 'on' ) ? 1 : 0;
        if ( $sp3 == 1 )
            echo "session.use_only_cookies - <span style='color: green'>OK</span><br>";
        else
            echo "session.use_only_cookies - <span style='color: red'>ERROR</span><br>";
        $sp4 = ( ini_get('session.auto_start') == 1 || strtolower(ini_get('session.auto_start')) == 'on' ) ? 0 : 1;
        if ( $sp4 == 1 )
            echo "session.auto_start - <span style='color: green'>OK</span><br>";
        else
            echo "session.auto_start - <span style='color: red'>ERROR</span><br>";
        $sp6 = ( ini_get('register_globals') == 1 || strtolower(ini_get('register_globals')) == 'on' ) ? 0 : 1;
        if ( $sp6 == 1 )
            echo "register_globals - <span style='color: green'>OK</span><br>";
        else
            echo "register_globals - <span style='color: red'>ERROR</span><br>";
        $sp7 = ( ini_get('display_errors') == 1 || strtolower(ini_get('display_errors')) == 'on' ) ? 0 : 1;
        if ( $sp7 == 1 )
            echo "display_errors - <span style='color: green'>OK</span><br>";
        else
            echo "display_errors - <span style='color: red'>ERROR</span><br>";
        $sp8 = ( ini_get('magic_quotes_runtime') == 1 || strtolower(ini_get('magic_quotes_runtime')) == 'on' ) ? 0 : 1;
        if ( $sp8 == 1 )
            echo "magic_quotes_runtime - <span style='color: green'>OK</span><br>";
        else
            echo "magic_quotes_runtime - <span style='color: red'>ERROR</span><br>";
        $sp29 = ( ini_get('allow_url_fopen') == 1 || strtolower(ini_get('allow_url_fopen')) == 'on' ) ? 1 : 0;
        if ( $sp29 == 1 )
            echo "allow_url_fopen - <span style='color: green'>OK</span>";
        else
            echo "allow_url_fopen - <span style='color: red'>ERROR</span>";
        echo "</td><td align=left valign=top style='padding-left: 30px;'><b>�������� ���������� PHP</b><br><br>";
        $sp10 = ( extension_loaded('gd')) ? 1 : 0;
        if ( $sp10 == 1 )
            echo "gd - <span style='color: green'>OK</span><br>";
        else
            echo "gd - <span style='color: red'>ERROR</span><br>";
        $sp11 = ( extension_loaded('mysql')) ? 1 : 0;
        if ( $sp11 == 1 )
            echo "mysql - <span style='color: green'>OK</span><br>";
        else
            echo "mysql - <span style='color: red'>ERROR</span><br>";
        $sp12 = ( extension_loaded('session')) ? 1 : 0;
        if ( $sp12 == 1 )
            echo "session - <span style='color: green'>OK</span><br>";
        else
            echo "session - <span style='color: red'>ERROR</span><br>";
        $sp13 = ( extension_loaded('xml')) ? 1 : 0;
        if ( $sp13 == 1 )
            echo "xml - <span style='color: green'>OK</span><br>";
        else
            echo "xml - <span style='color: red'>ERROR</span><br>";
        $sp14 = ( extension_loaded('zlib')) ? 1 : 0;
        if ( $sp14 == 1 )
            echo "zlib - <span style='color: green'>OK</span>";
        else
            echo "zlib - <span style='color: red'>ERROR</span>";
        echo "</td><td align=left valign=top style='padding-left: 30px;'><b>������ ��������� �������</b><br><br>";
        $sp15 = ( $_SERVER["HTTP_HOST"] != "" ) ? 1 : 0;
        if ( $sp15 == 1 )
            echo "PHP Variables - <span style='color: green'>OK</span><br>";
        else
            echo "PHP Variables - <span style='color: red'>ERROR</span><br>";
			$dir1 = dirname($_SERVER['PHP_SELF']);
$sourcessrand = array("//" => "/", "\\" => "/");
$dir1 = strtr($dir1, $sourcessrand);
if ($dir1 != "/") $dir2 = "/"; else $dir2 = "";
$baseHTTPUrl = $_SERVER["HTTP_HOST"].$dir1.$dir2;
        if($sp29==1){
        $sp16 = ( file_get_contents("http://".$baseHTTPUrl."install_check.html") == 'on' ) ? 1 : 0;
        if ( $sp16 == 1 )
            echo "��������������� ������ - <span style='color: green'>OK</span>";
        else
            echo "��������������� ������ - <span style='color: red'>ERROR ��� .htaccess �� ��������������� ���������</span>";
		}else{ echo "��������������� ������ - <span style='color: red'>UNKNOWN (�� ���������� ��-�� ������ ��������������)</span>";
		$sp16 == 0;
		}
        echo "</td></tr></table>";
        if ( $sp1 == 1 && $sp2 == 1 && $sp3 == 1 && $sp4 == 1 && $sp6 == 1 && $sp29 == 1 && $sp7 == 1 && $sp8 == 1 && $sp10 == 1 && $sp11 == 1 && $sp12 == 1 && $sp13 == 1 && $sp14 == 1 && $sp15 == 1 && $sp16 == 1 )
            echo "<br><span style='color: green'><b>������ ������������� ����������� �����������.</b> ����������� ���������...</span>";
        else
            die("<br><span style='color: red'><b>����������� ��������� �� ��������!</b> ������ �� ������������� ����������� �����������.</span>");
        echo "<br><br><br><table class=adw><tr><td align=left valign=top><b>����� ������ �� ����� ����</b><br><br>";
        $p1 = ( is_writable("core/backup")) ? 1 : 0;
        if ( $p1 == 1 )
            echo "core/backup - <span style='color: green'>OK</span><br>";
        else
            echo "core/backup - <span style='color: red'>ERROR</span><br>";
        $p2 = ( is_writable("core/cache")) ? 1 : 0;
        if ( $p2 == 1 )
            echo "core/cache - <span style='color: green'>OK</span><br>";
        else
            echo "core/cache - <span style='color: red'>ERROR</span><br>";
        $p3 = ( is_writable("core/files")) ? 1 : 0;
        if ( $p3 == 1 )
            echo "core/files - <span style='color: green'>OK</span><br>";
        else
            echo "core/files - <span style='color: red'>ERROR</span><br>";
        $p4 = ( is_writable("core/temp")) ? 1 : 0;
        if ( $p4 == 1 )
            echo "core/temp - <span style='color: green'>OK</span><br>";
        else
            echo "core/temp - <span style='color: red'>ERROR</span><br>";
        echo "</td><td align=left valign=top style='padding-left: 30px;'><b>����� ������ �� ����� ������</b><br><br>";
        $p5 = ( is_writable("data/big")) ? 1 : 0;
        if ( $p5 == 1 )
            echo "data/big - <span style='color: green'>OK</span><br>";
        else
            echo "data/big - <span style='color: red'>ERROR</span><br>";
        $p6 = ( is_writable("data/category")) ? 1 : 0;
        if ( $p6 == 1 )
            echo "data/category - <span style='color: green'>OK</span><br>";
        else
            echo "data/category - <span style='color: red'>ERROR</span><br>";
        $p7 = ( is_writable("data/files")) ? 1 : 0;
        if ( $p7 == 1 )
            echo "data/files - <span style='color: green'>OK</span><br>";
        else
            echo "data/files - <span style='color: red'>ERROR</span><br>";
        $p8 = ( is_writable("data/flash")) ? 1 : 0;
        if ( $p8 == 1 )
            echo "data/flash - <span style='color: green'>OK</span><br>";
        else
            echo "data/flash - <span style='color: red'>ERROR</span><br>";
        $p9 = ( is_writable("data/images")) ? 1 : 0;
        if ( $p9 == 1 )
            echo "data/images - <span style='color: green'>OK</span><br>";
        else
            echo "data/images - <span style='color: red'>ERROR</span><br>";
        $p10 = ( is_writable("data/medium")) ? 1 : 0;
        if ( $p10 == 1 )
            echo "data/medium - <span style='color: green'>OK</span><br>";
        else
            echo "data/medium - <span style='color: red'>ERROR</span><br>";
        $p11 = ( is_writable("data/small")) ? 1 : 0;
        if ( $p11 == 1 )
            echo "data/small - <span style='color: green'>OK</span><br>";
        else
            echo "data/small - <span style='color: red'>ERROR</span><br>";
        echo "</td><td align=left valign=top style='padding-left: 30px;'><b>����� ������ �� �����</b><br><br>";
        $p15 = ( is_writable("core/config/connect.inc.php")) ? 1 : 0;
        if ( $p15 == 1 )
            echo "core/config/connect.inc.php - <span style='color: green'>OK</span><br>";
        else
            echo "core/config/connect.inc.php - <span style='color: red'>ERROR</span><br>";
        $p16 = ( is_writable("core/config/database_structure.xml")) ? 1 : 0;
        if ( $p16 == 1 )
            echo "core/config/database_structure.xml - <span style='color: green'>OK</span><br>";
        else
            echo "core/config/database_structure.xml - <span style='color: red'>ERROR</span><br>";
        $p17 = ( is_writable("core/config/paths.inc.php")) ? 1 : 0;
        if ( $p17 == 1 )
            echo "core/config/paths.inc.php - <span style='color: green'>OK</span><br>";
        else
            echo "core/config/paths.inc.php - <span style='color: red'>ERROR</span><br>";
        $p18 = ( is_writable("core/config/tables.inc.php")) ? 1 : 0;
        if ( $p18 == 1 )
            echo "core/config/tables.inc.php - <span style='color: green'>OK</span>";
        else
            echo "core/config/tables.inc.php - <span style='color: red'>ERROR</span>";
        echo "</td></tr></table>";
        if ( $p1 == 1 && $p2 == 1 && $p3 == 1 && $p4 == 1 && $p5 == 1 && $p6 == 1 && $p7 == 1 && $p8 == 1 && $p9 == 1 && $p10 == 1 && $p11 == 1 && $p15 == 1 && $p16 == 1 && $p17 == 1 && $p18 == 1 )
            echo "<br><span style='color: green'><b>����� ������ �� ����� � ����� ���������� �����.</b> ����������� ���������...</span><br><br>";
        else
            die("<br><span style='color: red'><b>����������� ��������� �� ��������!</b> ����� ������ �� ����� � ����� ���������� �������.</span><br><br>");
		$spss = ( file_get_contents("http://".$baseHTTPUrl."index.php") != 'Invalid license!' ) ? 1 : 0;
        if ( $spss == 1 && file_get_contents("core/config/license.txt"))
            echo "<br><span style='color: green'><b>���� ��������� ����������.</b> ����������� ���������...</span><br><br>";
        else
            die("<br><br><span style='color: red'><b>����������� ��������� �� ��������!</b> ���� ��������� �� ����������, ���� �� ������������ ��� ����� ������ ��� ��� ���� ������ �������.</span>");
   
    include ( "core/functions/functions.php" );
    include ( "install/xml_parser.php" );
    include ( "core/functions/admin/xml_installer.php" );
    include ( "core/functions/admin/serialization_functions.php" );
    include ( "core/functions/order_status_functions.php" );
    include ( "core/functions/setting_functions.php" );
    include ( "core/functions/category_functions.php" );
    include ( "core/functions/registration_functions.php" );
    include ( "core/functions/statistic_functions.php" );
    include ( "core/functions/datetime_functions.php" );
    include ( "core/functions/aux_pages_functions.php" );
    include ( "core/functions/crypto_functions.php" );
    include ( "install/consts.php" );
    include ( "core/functions/payment_functions.php" );
    include ( "core/config/paths.inc.php" );
    include ( "core/functions/version_function.php" );
    include ( "core/functions/session_functions.php" );
    define("SECURITY_EXPIRE", 3600);
    define('PATH_DELIMITER', isWindows() ? ';' : ':');

    function _testWriteable() {
        if ( !IsWriteable(DATABASE_STRUCTURE_XML_PATH))
            return STRING_COULDNT_REWRITE_FILE." ".DATABASE_STRUCTURE_XML_PATH;
        if ( !IsWriteable(TABLES_INC_PHP_PATH))
            return STRING_COULDNT_REWRITE_FILE." ".TABLES_INC_PHP_PATH;
        if ( !IsWriteable(CONNECT_INC_PHP_PATH))
            return STRING_COULDNT_REWRITE_FILE." ".CONNECT_INC_PHP_PATH;
        if ( file_exists(RESULT_XML_PATH)) {
            if ( !IsWriteable(RESULT_XML_PATH))
                return STRING_COULDNT_REWRITE_FILE." ".RESULT_XML_PATH;
        }
        return "";
    }

    function _reWriteInstallXmlFile() {
        ReWriteInstallXmlFile(DATABASE_STRUCTURE_XML_PATH, $_SESSION["tableFileName"], RESULT_XML_PATH);
        unlink(DATABASE_STRUCTURE_XML_PATH);
        rename(RESULT_XML_PATH, DATABASE_STRUCTURE_XML_PATH);
    }

    function _installNewDataBase($databaseHost, $databaseUsername, $databasePassword, $databaseName, $adminLogin, $adminPassword, $install_prefix) {
        $tables = db_get_all_ss_tables(DATABASE_STRUCTURE_XML_PATH);
        foreach ( $tables as $tableName )
            db_delete_table($tableName);
        CreateTablesIncFile("core/config/tables.inc.php", DATABASE_STRUCTURE_XML_PATH);
        $error = "";
        // rewrite "core/config/connect.inc.php"
        if ( !is_writable("core/config/connect.inc.php"))
            $error = "Couldn't rewrite file core/config/connect.inc.php.";
        else {
            $f = fopen("core/config/connect.inc.php", "w");
            $s = "<?php\n"."//database connection settings\n"."define('DBMS', 'mysql');                      // database system  \n"."define('DB_HOST', '".$databaseHost."');       // database host    \n"."define('DB_USER', '".$databaseUsername."');   // username         \n"."define('DB_PASS', '".$databasePassword."');   // password         \n"."define('DB_NAME', '".$databaseName."');       // database name    \n"."define('DB_PRFX', '".$install_prefix."');     // database prefix  \n"."\n"."// include table name file\n"."include('core/config/tables.inc.php');\n"."define('ALTERNATEPHP', '".$_SESSION["alternatephp"]."');\n"."?>";
            fputs($f, $s);
            fclose($f);
        }
        if ( $error != "" )  die($error);
        // include connect file
        include ( "core/config/connect.inc.php" );
        // installation routine
        // create tables without constraints
        CreateTablesStructureXML(DATABASE_STRUCTURE_XML_PATH);
        //CreateTablesIncFile( "core/config/tables.inc.php", DATABASE_STRUCTURE_XML_PATH );
        // settings
        serImportWithConstantNameReplacing("install/sql/setting_groups.sql");
        serImportWithConstantNameReplacing("install/sql/setting_constants.sql", true);
        _initializeAuxPages();
        // a
        serImportWithConstantNameReplacing("install/sql/localization.sql");
        // b
        serImportWithConstantNameReplacing("install/sql/currencies.sql");
        _setDefaultCurrency();
        // c
        serImportWithConstantNameReplacing("install/sql/order_statuses.sql");
        _setNewOrderStatus();
        _setCompletedStatus();
        // d
        serImportWithConstantNameReplacing("install/sql/customer_groups.sql");
        _setCustGroupByDefault();
        // e
        serImportWithConstantNameReplacing("install/sql/shipping_methods.sql");
        // f
        serImportWithConstantNameReplacing("install/sql/payment_types.sql");
        _setPaymentShippingMethod();
        // create refer constraints
        $sql = CreateReferConstraintsXML(DATABASE_STRUCTURE_XML_PATH);
        session_write_close();
        settingDefineConstants();
        // register admin
        regRegisterAdmin($adminLogin, $adminPassword);
    }

    function _setDefaultCurrency() {
        _setSettingOptionValue("CONF_DEFAULT_CURRENCY", 1);
    }

    function _setNewOrderStatus() {
        _setSettingOptionValue("CONF_NEW_ORDER_STATUS", 2);
    }

    function _setCompletedStatus() {
        _setSettingOptionValue("CONF_COMPLETED_ORDER_STATUS", 5);
    }

    function _setCustGroupByDefault() {
        _setSettingOptionValue("CONF_DEFAULT_CUSTOMER_GROUP", 1);
    }

    function _setPaymentShippingMethod() {
        payResetPaymentShippingMethods(1);
        paySetPaymentShippingMethod(1, 1);
    }

    function _initializeAuxPages() {
        $aux_page_text = AUX_PAGE_TEXT_INSTALL;
        auxpgAddAuxPage(AUX_PAGE_TITLE_INSTALL, $aux_page_text, 1, "", "", "");
    }


    if ( isset ( $_POST["next"] )) {
        @set_time_limit(0);

        include ( "core/includes/database/mysql.php" );
        include ( "core/functions/placeholders_functions.php" );

        if ( !db_connect(trim($_POST["_databaseHost"]), trim($_POST["_databaseUsername"]), trim($_POST["_databasePassword"]))) {
            echo "���������� � �������� Mysql - <span style='color: red'>ERROR!</span><br><br><span style='color: red'><b>����������� ��������� �� ��������!</b> ������ ��� ���������� � �������� Mysql ������� �������.</span>";
                      die();
        }

        if ( !db_select_db(trim($_POST["_databaseName"])) ) {
           echo "����� ���� ������ - <span style='color: red'>ERROR!</span><br><br><span style='color: red'><b>����������� ��������� �� ��������!</b> ��� ���� ������� �������.</span>";
                die();
        }
		
        $install_prefix = trim($_POST["install_prefix_x"]);
        $XMLDataWrite = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>
<DataBaseStructure ApplicationVersion='ShopCMS' LastModifyDate='05/05/2009'>
        <tables>

                <table name='".$install_prefix."system' alias='SYSTEM_TABLE' >
                        <column TYPE='varchar(255)' >varName</column>
                        <column TYPE='varchar(255)' >value</column>
                </table>

                <table name='".$install_prefix."session' alias='SESSION_TABLE' >
                        <column type='varchar(32)' PrimaryKey='true' nullable='false' >id</column>
                        <column type='text' nullable='false' >data</column>
                        <column type='int' nullable='false' default='0' >expire</column>
                        <column type='varchar(15)' nullable='false' >IP</column>
                        <column type='varchar(255)' nullable='false' >Referer</column>
                        <column type='varchar(255)' nullable='false' >user_agent</column>
                        <column type='text' nullable='false' >URL</column>
                </table>

                <table name='".$install_prefix."blocks' alias='BLOCKS_TABLE' >
                        <column type='int' PrimaryKey='true' identity='true' >bid</column>
                        <column type='varchar(255)' nullable='false' >title</column>
                        <column type='text' nullable='false' >content</column>
                        <column type='int' nullable='false' default='0' >bposition</column>
                        <column type='int' nullable='false' default='1' index='active' >active</column>
                        <column type='int' nullable='false' default='0' >which</column>
                        <column type='int' nullable='false' default='0' >sort</column>
                        <column type='int' nullable='false' default='0' >html</column>
                        <column type='varchar(255)' nullable='false' >url</column>
                        <column type='int' nullable='false' default='0' >admin</column>
                        <column type='text' nullable='false' >about</column>
                        <column type='text' nullable='false' >pages</column>
                        <column type='text' nullable='false' >dpages</column>
                        <column type='text' nullable='false' >categories</column>
                        <column type='text' nullable='false' >products</column>
                </table>

                <table name='".$install_prefix."related_content_cat' alias='RELATED_CONTENT_CAT_TABLE' >
                        <column type='int' nullable='false' default='0' index='categoryID' >categoryID</column>
                        <column type='int' nullable='false' default='0' >Owner</column>
                </table>

                <table name='".$install_prefix."related_content' alias='RELATED_CONTENT_TABLE' >
                        <column type='int' nullable='false' default='0' index='productID' >productID</column>
                        <column type='int' nullable='false' default='0' >Owner</column>
                </table>

                <table name='".$install_prefix."online' alias='ONLINE_TABLE' >
                        <column type='varchar(32)' PrimaryKey='true' nullable='false' >uname</column>
                        <column type='varchar(14)' nullable='false' >time</column>
                </table>

                <table name='".$install_prefix."survey' alias='SURVEY_TABLE' >
                        <column type='int' PrimaryKey='true' identity='true' >poll_id</column>
                        <column type='datetime' nullable='true' >poll_date</column>
                        <column type='varchar(255)' nullable='false' >poll_title</column>
                        <column type='text' nullable='false' >poll_ans</column>
                        <column type='int' nullable='false' default='0' >ans_0</column>
                        <column type='int' nullable='false' default='0' >ans_1</column>
                        <column type='int' nullable='false' default='0' >ans_2</column>
                        <column type='int' nullable='false' default='0' >ans_3</column>
                        <column type='int' nullable='false' default='0' >ans_4</column>
                        <column type='int' nullable='false' default='0' >ans_5</column>
                        <column type='int' nullable='false' default='0' >ans_6</column>
                        <column type='int' nullable='false' default='0' >ans_7</column>
                        <column type='int' nullable='false' default='0' >ans_8</column>
                        <column type='int' nullable='false' default='0' >ans_9</column>
                        <column type='int' nullable='false' default='0' >all_poll</column>
                        <column type='int' nullable='false' default='0' >active</column>
                                                <column type='longtext' nullable='false' >iplog</column>
                                                <column type='datetime' nullable='true' >tdate</column>
                </table>

                <table name='".$install_prefix."error_log' alias='ERROR_LOG_TABLE' >
                        <column type='text' nullable='false' >errors</column>
                                                <column type='timestamp' nullable='false' >tstamp</column>
                </table>

                <table name='".$install_prefix."mysql_error_log' alias='MYSQL_ERROR_LOG_TABLE' >
                        <column type='text' nullable='false' >errors</column>
                                                <column type='timestamp' nullable='false' >tstamp</column>
                </table>

                <table name='".$install_prefix."counter' alias='COUNTER_TABLE' >
                        <column type='int' nullable='false' default='1' >tbid</column>
                        <column type='int' nullable='false' default='0' >todayp</column>
                        <column type='int' nullable='false' default='0' >todayv</column>
                        <column type='int' nullable='false' default='0' >allp</column>
                        <column type='int' nullable='false' default='0' >allv</column>
                        <column type='int' nullable='false' default='0' >allieb</column>
                        <column type='int' nullable='false' default='0' >allmozb</column>
                        <column type='int' nullable='false' default='0' >allopb</column>
                        <column type='int' nullable='false' default='0' >allozb</column>
                        <column type='int' nullable='false' default='0' >allrusl</column>
                        <column type='int' nullable='false' default='0' >allenl</column>
                        <column type='int' nullable='false' default='0' >allozl</column>
                        <column type='int' nullable='false' default='0' >allwins</column>
                        <column type='int' nullable='false' default='0' >alllins</column>
                        <column type='int' nullable='false' default='0' >allmacs</column>
                        <column type='int' nullable='false' default='0' >allozs</column>
                        <column type='varchar(20)' nullable='false' default='0' >today</column>
                </table>

                <table name='".$install_prefix."dump' alias='DUMP_TABLE' >
                        <column type='int' >type</column>
                        <column type='int' nullable='false' >last_update</column>
                </table>

                <table name='".$install_prefix."orders' alias='ORDERS_TABLE' >
                        <column type='int' primarykey='true' identity='true'>orderID</column>
                        <column type='int'>customerID</column>
                        <column type='datetime'>order_time</column>
                        <column type='varchar(15)'>customer_ip</column>
                        <column type='varchar(64)'>shipping_type</column>
                        <column type='varchar(64)'>payment_type</column>
                        <column type='text'>customers_comment</column>
                        <column type='int'>statusID</column>
                        <column type='double'>shipping_cost</column>
                        <column type='double'>order_discount</column>
                        <column type='double'>order_amount</column>
                        <column type='varchar(12)'>currency_code</column>
                        <column type='float'>currency_value</column>
                        <column type='varchar(64)'>customer_firstname</column>
                        <column type='varchar(64)'>customer_lastname</column>
                        <column type='varchar(50)'>customer_email</column>
                        <column type='varchar(64)'>shipping_firstname</column>
                        <column type='varchar(64)'>shipping_lastname</column>
                        <column type='varchar(64)'>shipping_country</column>
                        <column type='varchar(64)'>shipping_state</column>
                        <column type='varchar(64)'>shipping_city</column>
                        <column type='text'>shipping_address</column>
                        <column type='varchar(64)'>billing_firstname</column>
                        <column type='varchar(64)'>billing_lastname</column>
                        <column type='varchar(64)'>billing_country</column>
                        <column type='varchar(64)'>billing_state</column>
                        <column type='varchar(64)'>billing_city</column>
                        <column type='text'>billing_address</column>
                        <column type='varchar(255)'>cc_number</column>
                        <column type='varchar(255)'>cc_holdername</column>
                        <column type='char(255)'>cc_expires</column>
                        <column type='varchar(255)'>cc_cvv</column>
                        <column type='int' default='0'>affiliateID</column>
                        <column type='varchar(255)' >shippingServiceInfo</column>
                        <column type='varchar(36)' >custlink</column>
                        <column type='int' default='2'>currency_round</column>
                        <column type='int'>paymethod</column>
                </table>

                <table name='".$install_prefix."order_status' alias='ORDER_STATUES_TABLE' >
                        <column type='int' PrimaryKey='true' identity='true'>statusID</column>
                        <column type='varchar(60)'>status_name</column>
                        <column type='int'>sort_order</column>
                </table>

                <table name='".$install_prefix."ordered_carts' alias='ORDERED_CARTS_TABLE' >
                        <column type='int' PrimaryKey='true'>itemID</column>
                        <column type='int' PrimaryKey='true'>orderID</column>
                        <column type='varchar(255)'>name</column>
                        <column type='double'>Price</column>
                        <column type='int'>Quantity</column>
                        <column type='double'>tax</column>
                        <column type='int' default='0'>load_counter</column>
                </table>

                <table name='".$install_prefix."products' alias='PRODUCTS_TABLE' ProductAndCategorySync='true' >
                        <column type='int' PrimaryKey='true' identity='true'>productID</column>
                        <column type='int' index='IDX_PRODUCTS1'>categoryID</column>
                        <column type='varchar(255)'>name</column>
                        <column type='text'>description</column>
                        <column type='float' default='0'>customers_rating</column>
                        <column type='double'>Price</column>
                        <column type='int'>in_stock</column>
                        <column type='int' default='0'>customer_votes</column>
                        <column type='int' nullable='false'>items_sold</column>
                        <column type='int'>enabled</column>
                        <column type='text'>brief_description</column>
                        <column type='double'>list_price</column>
                        <column type='varchar(25)'>product_code</column>
                        <column type='int' default='0'>sort_order</column>
                        <column type='int'>default_picture</column>
                        <column type='datetime'>date_added</column>
                        <column type='datetime'>date_modified</column>
                        <column type='int' default='0'>viewed_times</column>
                        <column type='varchar(255)'>eproduct_filename</column>
                        <column type='int' default='5'>eproduct_available_days</column>
                        <column type='int' default='5'>eproduct_download_times</column>
                        <column type='float' default='0'>weight</column>
                        <column type='text'>meta_description</column>
                        <column type='text'>meta_keywords</column>
                        <column type='int' default='0'>free_shipping</column>
                        <column type='int' default='1'>min_order_amount</column>
                        <column type='double' default='0'>shipping_freight</column>
                        <column type='int'>classID</column>
                        <column type='text'>title</column>
                </table>

                <table name='".$install_prefix."categories' alias='CATEGORIES_TABLE' ProductAndCategorySync='true' >
                        <column type='int' PrimaryKey='true' identity='true'>categoryID</column>
                        <column type='varchar(255)'>name</column>
                        <column type='int' index='IDX_CATEGORIES1'>parent</column>
                        <column type='int'>products_count</column>
                        <column type='text'>description</column>
                        <column type='varchar(30)'>picture</column>
                        <column type='int'>products_count_admin</column>
                        <column type='int' default='0' index='sort_order'>sort_order</column>
                        <column type='int' default='0'>viewed_times</column>
                        <column type='int' default='0'>allow_products_comparison </column>
                        <column type='int' default='1'>allow_products_search</column>
                        <column type='int' default='1'> show_subcategories_products </column>
                        <column type='text'>meta_description</column>
                        <column type='text'>meta_keywords</column>
                        <column type='text'>title</column>
                        <column type='int' default='0'>subcount</column>
                </table>

                <table name='".$install_prefix."category_product' alias='CATEGORIY_PRODUCT_TABLE' ProductAndCategorySync='true' >
                        <column type='int' PrimaryKey='true'>productID</column>
                        <column type='int' PrimaryKey='true'>categoryID</column>
                </table>

                <table name='".$install_prefix."shopping_carts' alias='SHOPPING_CARTS_TABLE' >
                        <column type='int' PrimaryKey='true'>customerID</column>
                        <column type='int' PrimaryKey='true'>itemID</column>
                        <column type='int'>Quantity</column>
                </table>

                <table name='".$install_prefix."news_table' alias='NEWS_TABLE' >
                        <column type='int' PrimaryKey='true' identity='true'>NID</column>
                        <column type='date'>add_date</column>
                        <column type='text'>title</column>
                        <column type='text'>textToPrePublication</column>
                        <column type='text'>textToPublication</column>
                        <column type='text'>textToMail</column>
                        <column type='int'>add_stamp</column>
                </table>

                <table name='".$install_prefix."discussions' alias='DISCUSSIONS_TABLE' ProductAndCategorySync='true' >
                        <column type='int' PrimaryKey='true' identity='true'>DID</column>
                        <column type='int'>productID</column>
                        <column type='varchar(40)'>Author</column>
                        <column type='text'>Body</column>
                        <column type='datetime'>add_time</column>
                        <column type='varchar(255)'>Topic</column>
                </table>

                <table name='".$install_prefix."subscribers' alias='MAILING_LIST_TABLE' >
                        <column type='int' PrimaryKey='true' identity='true'>MID</column>
                        <column type='varchar(50)'>Email</column>
                        <column type='int' nullable='true'>customerID</column>
                </table>

                <table name='".$install_prefix."related_items' alias='RELATED_PRODUCTS_TABLE' ProductAndCategorySync='true' >
                        <column type='int' PrimaryKey='true'>productID</column>
                        <column type='int' PrimaryKey='true'>Owner</column>
                </table>

                <table name='".$install_prefix."product_options' alias='PRODUCT_OPTIONS_TABLE' ProductAndCategorySync='true' >
                        <column type='int' PrimaryKey='true' identity='true'>optionID</column>
                        <column type='varchar(60)'>name</column>
                        <column type='int' default='0'>sort_order</column>
                </table>

                <table name='".$install_prefix."product_options_values' alias='PRODUCT_OPTIONS_VALUES_TABLE' ProductAndCategorySync='true' >
                        <column type='int' PrimaryKey='true'>optionID</column>
                        <column type='int' PrimaryKey='true' index='IDX_OPTVALUES1'>productID</column>
                        <column type='varchar(255)'>option_value</column>
                        <column type='int' default='0'>option_type</column>
                        <column type='int' default='1'>option_show_times</column>
                        <column type='int' index='IDX_OPTVALUES2'>variantID</column>
                </table>

                <table name='".$install_prefix."products_opt_val_variants' alias='PRODUCTS_OPTIONS_VALUES_VARIANTS_TABLE'  ProductAndCategorySync='true' >
                        <column type='int' PrimaryKey='true' identity='true'>variantID</column>
                        <column type='int' nullable='false' index='IDX_VARIANTS1'>optionID</column>
                        <column type='varchar(255)'>option_value</column>
                        <column type='int' default='0'>sort_order</column>
                </table>

                <table name='".$install_prefix."product_options_set' alias='PRODUCTS_OPTIONS_SET_TABLE' ProductAndCategorySync='true' >
                        <column type='int' PrimaryKey='true'>productID</column>
                        <column type='int' PrimaryKey='true'>optionID</column>
                        <column type='int' PrimaryKey='true'>variantID</column>
                        <column type='double' default='0'>price_surplus</column>
                </table>

                <table name='".$install_prefix."customers' alias='CUSTOMERS_TABLE' >
                        <column type='int' PrimaryKey='true' identity='true'>customerID</column>
                        <column type='varchar(32)'>Login</column>
                        <column type='varchar(255)' nullable='false'>cust_password</column>
                        <column type='varchar(64)'>Email</column>
                        <column type='varchar(32)'>first_name</column>
                        <column type='varchar(32)'>last_name</column>
                        <column type='int'>subscribed4news</column>
                        <column type='int'>custgroupID</column>
                        <column type='int'>addressID</column>
                        <column type='datetime'>reg_datetime</column>
                        <column type='varchar(16)' nullable='false' default='\"\"' >ActivationCode</column>
                        <column type='int'>CID</column>
                        <column type='int' nullable='false' index='affiliateID'>affiliateID</column>
                        <column type='int' nullable='false' default='1'>affiliateEmailOrders</column>
                        <column type='int' nullable='false' default='1'>affiliateEmailPayments</column>
                        <column type='text' nullable='false'>actions</column>
                </table>

                <table name='".$install_prefix."custgroups' alias='CUSTGROUPS_TABLE' >
                        <column type='int' PrimaryKey='true' identity='true'>custgroupID</column>
                        <column type='varchar(64)'>custgroup_name</column>
                        <column type='float' default='0'>custgroup_discount</column>
                        <column type='int' default='0'>sort_order</column>
                </table>

                <table name='".$install_prefix."countries' alias='COUNTRIES_TABLE' >
                        <column type='int' PrimaryKey='true' identity='true'>countryID</column>
                        <column type='varchar(64)'>country_name</column>
                        <column type='char(2)'>country_iso_2</column>
                        <column type='char(3)'>country_iso_3</column>
                </table>

                <table name='".$install_prefix."zones' alias='ZONES_TABLE' >
                        <column type='int' PrimaryKey='true' identity='true'>zoneID</column>
                        <column type='varchar(64)'>zone_name</column>
                        <column type='char(64)'>zone_code</column>
                        <column type='int'>countryID</column>
                </table>

                <table name='".$install_prefix."customer_log' alias='CUSTOMER_LOG_TABLE' >
                        <column type='int' nullable='false'>customerID</column>
                        <column type='varchar(15)'>customer_ip</column>
                        <column type='datetime'>customer_logtime</column>
                </table>

                <table name='".$install_prefix."customer_addresses' alias='CUSTOMER_ADDRESSES_TABLE' >
                        <column type='int' PrimaryKey='true' identity='true'>addressID</column>
                        <column type='int' nullable='false'>customerID</column>
                        <column type='varchar(64)'>first_name</column>
                        <column type='varchar(64)'>last_name</column>
                        <column type='int' nullable='true'>countryID</column>
                        <column type='int' nullable='true'>zoneID</column>
                        <column type='varchar(64)'>state</column>
                        <column type='varchar(64)'>city</column>
                        <column type='text'>address</column>
                </table>

                <table name='".$install_prefix."customer_reg_fields' alias='CUSTOMER_REG_FIELDS_TABLE' >
                        <column type='int' PrimaryKey='true' identity='true'>reg_field_ID</column>
                        <column type='varchar(60)'>reg_field_name</column>
                        <column type='int'>reg_field_required</column>
                        <column type='int'>sort_order</column>
                </table>

                <table name='".$install_prefix."customer_reg_fields_values' alias='CUSTOMER_REG_FIELDS_VALUES_TABLE' >
                        <column type='int' nullable='false'>reg_field_ID</column>
                        <column type='int' nullable='false'>customerID</column>
                        <column type='varchar(255)'>reg_field_value</column>
                </table>

                <table name='".$install_prefix."customer_reg_fields_values_quickreg' alias='CUSTOMER_REG_FIELDS_VALUES_TABLE_QUICKREG' >
                        <column type='int' nullable='false'>reg_field_ID</column>
                        <column type='int' nullable='false'>orderID</column>
                        <column type='varchar(255)'>reg_field_value</column>
                </table>


                <table name='".$install_prefix."shipping_methods' alias='SHIPPING_METHODS_TABLE' >
                        <column type='int' PrimaryKey='true' identity='true'>SID</column>
                        <column type='varchar(60)'>Name</column>
                        <column type='varchar(255)'>description</column>
                        <column type='text'>email_comments_text</column>
                        <column type='int'>Enabled</column>
                        <column type='int'>module_id</column>
                        <column type='int' default='0'>sort_order</column>
                </table>

                <table name='".$install_prefix."payment_types' alias='PAYMENT_TYPES_TABLE' >
                        <column type='int' PrimaryKey='true' identity='true'>PID</column>
                        <column type='varchar(60)'>Name</column>
                        <column type='varchar(255)'>description</column>
                        <column type='int'>Enabled</column>
                        <column type='int'>calculate_tax</column>
                        <column type='int' default='0'>sort_order</column>
                        <column type='text'>email_comments_text</column>
                        <column type='int'>module_id</column>
                </table>

                <table name='".$install_prefix."payment_types__shipping_methods' alias='SHIPPING_METHODS_PAYMENT_TYPES_TABLE' >
                        <column type='int' PrimaryKey='true'>SID</column>
                        <column type='int' PrimaryKey='true'>PID</column>
                </table>

                <table name='".$install_prefix."currency_types' alias='CURRENCY_TYPES_TABLE' >
                        <column type='int' PrimaryKey='true' identity='true'>CID</column>
                        <column type='varchar(60)'>Name</column>
                        <column type='varchar(60)'>code</column>
                        <column type='float'>currency_value</column>
                        <column type='int'>where2show</column>
                        <column type='int' default='0'>sort_order</column>
                        <column type='char(3)'>currency_iso_3</column>
                        <column type='int' default='2'>roundval</column>
                </table>

                <table name='".$install_prefix."special_offers' alias='SPECIAL_OFFERS_TABLE' ProductAndCategorySync='true' >
                        <column type='int' PrimaryKey='true' identity='true'>offerID</column>
                        <column type='int'>productID</column>
                        <column type='int' default='0'>sort_order</column>
                </table>

                <table name='".$install_prefix."shopping_cart_items' alias='SHOPPING_CART_ITEMS_TABLE' >
                        <column type='int' PrimaryKey='true' identity='true'>itemID</column>
                        <column type='int'>productID</column>
                </table>

                <table name='".$install_prefix."shopping_cart_items_content' alias='SHOPPING_CART_ITEMS_CONTENT_TABLE' >
                        <column type='int' nullable='false'>itemID</column>
                        <column type='int' nullable='false'>variantID</column>
                </table>

                <table name='".$install_prefix."product_pictures' alias='PRODUCT_PICTURES' ProductAndCategorySync='true' >
                        <column type='int' PrimaryKey='true' identity='true'>photoID</column>
                        <column type='int' nullable='false'>productID</column>
                        <column type='varchar(50)'>filename</column>
                        <column type='varchar(50)'>thumbnail</column>
                        <column type='varchar(50)'>enlarged</column>
                </table>

                <table name='".$install_prefix."aux_pages' alias='AUX_PAGES_TABLE' >
                        <column type='int' PrimaryKey='true' identity='true'>aux_page_ID</column>
                        <column type='varchar(255)'>aux_page_name</column>
                        <column type='text'>aux_page_text</column>
                        <column type='int'>aux_page_text_type</column>
                        <column type='text'>meta_keywords</column>
                        <column type='text'>meta_description</column>
                        <column type='text'>title</column>
                </table>

                <table name='".$install_prefix."settings_groups' alias='SETTINGS_GROUPS_TABLE' >
                        <column type='int' PrimaryKey='true' identity='true'>settings_groupID</column>
                        <column type='varchar(64)'>settings_group_name</column>
                        <column type='int' default='0'>sort_order</column>
                </table>

                <table name='".$install_prefix."settings' alias='SETTINGS_TABLE' >
                        <column type='int' PrimaryKey='true' identity='true'>settingsID</column>
                        <column type='int'>settings_groupID</column>
                        <column type='varchar(64)'>settings_constant_name</column>
                        <column type='varchar(255)'>settings_value</column>
                        <column type='varchar(128)'>settings_title</column>
                        <column type='varchar(255)'>settings_description</column>
                        <column type='varchar(255)'>settings_html_function</column>
                        <column type='int' default='0'>sort_order</column>
                </table>

                <table name='".$install_prefix."category__product_options' alias='CATEGORY_PRODUCT_OPTIONS_TABLE' >
                        <column type='int' PrimaryKey='true'>optionID</column>
                        <column type='int' PrimaryKey='true'>categoryID</column>
                        <column type='int' default='1'>set_arbitrarily</column>
                </table>

                <table name='".$install_prefix."category_product_options__variants' alias='CATEGORY_PRODUCT_OPTION_VARIANTS' >
                        <column type='int' PrimaryKey='true'>optionID</column>
                        <column type='int' PrimaryKey='true'>categoryID</column>
                        <column type='int' PrimaryKey='true'>variantID</column>
                </table>

                <table name='".$install_prefix."tax_classes' alias='TAX_CLASSES_TABLE' >
                        <column type='int' PrimaryKey='true' identity='true'>classID</column>
                        <column type='varchar(64)'>name</column>
                        <column type='int'>address_type</column>
                </table>

                <table name='".$install_prefix."tax_rates' alias='TAX_RATES_TABLE' >
                        <column type='int' PrimaryKey='true'>classID</column>
                        <column type='int' PrimaryKey='true'>countryID</column>
                        <column type='int'>isGrouped</column>
                        <column type='float'>value</column>
                        <column type='int'>isByZone</column>
                </table>

                <table name='".$install_prefix."tax_rates__zones' alias='TAX_RATES_ZONES_TABLE' >
                        <column type='int' PrimaryKey='true'>classID</column>
                        <column type='int' PrimaryKey='true'>zoneID</column>
                        <column type='float'>value</column>
                        <column type='int'>isGrouped</column>
                </table>

                <table name='".$install_prefix."tax_zip' alias='TAX_ZIP_TABLE' >
                        <column type='int' PrimaryKey='true' identity='true'>tax_zipID</column>
                        <column type='int'>classID</column>
                        <column type='int'>countryID</column>
                        <column type='varchar(255)'>zip_template</column>
                        <column type='float'>value</column>
                </table>

                <table name='".$install_prefix."modules' alias='MODULES_TABLE' >
                        <column type='int' PrimaryKey='true' identity='true'>module_id</column>
                        <column type='varchar(255)'>module_name</column>
                        <column TYPE='varchar(255)'>ModuleClassName</column>
                </table>

                <table name='".$install_prefix."order_price_discount' alias='ORDER_PRICE_DISCOUNT_TABLE' >
                        <column type='int' PrimaryKey='true' identity='true'>discount_id</column>
                        <column type='double'>price_range</column>
                        <column type='double'>percent_discount</column>
                </table>

                <table name='".$install_prefix."order_status_changelog' alias='ORDER_STATUS_CHANGE_LOG_TABLE' >
                        <column type='int'>orderID</column>
                        <column type='varchar(255)'>status_name</column>
                        <column type='datetime'>status_change_time</column>
                        <column type='text'>status_comment</column>
                </table>

                <table name='".$install_prefix."linkexchange_categories' alias='LINK_EXCHANGE_CATEGORIES_TABLE' >
                        <column type='int' PrimaryKey='true' identity='true'>le_cID</column>
                        <column type='varchar(100)'>le_cName</column>
                        <column type='int'>le_cSortOrder</column>
                </table>

                <table name='".$install_prefix."linkexchange_links' alias='LINK_EXCHANGE_LINKS_TABLE' >
                        <column type='int' PrimaryKey='true' identity='true'>le_lID</column>
                        <column type='varchar(255)'>le_lText</column>
                        <column type='text'>le_lDesk</column>
                        <column type='varchar(255)'>le_lURL</column>
                        <column type='int'>le_lCategoryID</column>
                        <column type='datetime'>le_lVerified</column>
                </table>

                <table name='".$install_prefix."aff_commissions' alias='AFFILIATE_COMMISSIONS_TABLE' >
                        <column type='int' PrimaryKey='true' identity='true'>cID</column>
                        <column type='double'>Amount</column>
                        <column type='varchar(3)'>CurrencyISO3</column>
                        <column type='datetime'>xDateTime</column>
                        <column type='varchar(255)'>Description</column>
                        <column type='int'>OrderID</column>
                        <column type='int' index='CustomerID'>CustomerID</column>
                </table>

                <table name='".$install_prefix."aff_payments' alias='AFFILIATE_PAYMENTS_TABLE' >
                        <column type='int' PrimaryKey='true' identity='true'>pID</column>
                        <column type='int' index='CustomerID'>CustomerID</column>
                        <column type='double'>Amount</column>
                        <column type='varchar(3)'>CurrencyISO3</column>
                        <column type='date'>xDate</column>
                        <column type='varchar(255)'> Description</column>
                </table>

        </tables>
</DataBaseStructure>";
        if ( file_exists("core/config/database_structure.xml") && $fhandle = fopen("core/config/database_structure.xml", "r+")) {
            fwrite($fhandle, $XMLDataWrite);
            fclose($fhandle);
        }
        else {
		     $GLOBALS['_RESULT'] = array( "result" => "core/config/database_structure.xml" );
             die("core/config/database_structure.xml");
        }
        
		if(file_exists("core/cache/incache.php")) unlink ("core/cache/incache.php");
        if(file_exists("core/cache/fcache.php"))  unlink ("core/cache/fcache.php");
		if(file_exists("core/cache/afcache.php")) unlink ("core/cache/afcache.php");
        
		$_SESSION["alternatephp"] = 1;
        _installNewDataBase(trim($_POST["_databaseHost"]), trim($_POST["_databaseUsername"]), trim($_POST["_databasePassword"]), trim($_POST["_databaseName"]), trim($_POST["adminLogin"]), trim($_POST["adminPassword"]), $install_prefix);
        $pl = mysql_query("select value from ".$install_prefix."system where varName='version_number'");
        $vall = mysql_fetch_row($pl);
        if ( $vall[0] != "ShopCMS 3.1.3" ) {
            $_SESSION["alternatephp"] = 9;
        _installNewDataBase(trim($_POST["_databaseHost"]), trim($_POST["_databaseUsername"]), trim($_POST["_databasePassword"]), trim($_POST["_databaseName"]), trim($_POST["adminLogin"]), trim($_POST["adminPassword"]), $install_prefix);
            $pl = mysql_query("select value from ".$install_prefix."system where varName='version_number'");
            $vall = mysql_fetch_row($pl);
            if ( $vall[0] != "ShopCMS 3.1.3" ) {
                  echo "<span style='color: red'>�������� ������! ���������� � �������������.</span>";
                     die();
            }
        }
       echo "<span style='color: green'><b>��������� ������� ���������!</b></span><br><br><a href='index.php'>������� �� ������� ��������</a> | <a href='admin.php'>������� � �����������������</a><br><br>";
        die();
    }
    ?>
<br><table class="adw" align="left">
  <tr>
    <td align="left">
	  <form name='MainForm' id="MainForm" method=POST action="">
        <table class="adw" align="left" width="524">
          <tr>
            <td align=left valign=top>
              <table class="adn" style="height: 100%; margin-left: -34px;">
                <tr>
				  <td style="height: 42px; padding: 0 34px;" class="vcent"><div align="left" style="line-height:16px;"><b>������� ������ ����������� � ��</b><br><span style="color: #575757;">��� ������� � ���� ������ � ��������� ���� ��������� ��� ����� ������������!</span></div></td>
                </tr>
                <tr>
				  <td style="padding: 0 34px;" class="vcent">
                    <table class="adn">
                      <tr>
                        <td style="width: 10%;"><div style="padding-bottom: 3px;">���� ��:</div><input type="text" name="_databaseHost"  id="_databaseHost" value='localhost' style="width: 60px;"></td>
                        <td style="padding-left: 10px;"><div style="padding-bottom: 3px;">������� ��:</div><input type="text" id="install_prefix_x" name="install_prefix_x" value='' style="width: 40px;"><input type=button value="Random" onclick="randomPass(); return false;" style="margin-left: 10px;"></td>
                        <td align="left" style="width: 228px;"><div align="left" style="padding-bottom: 3px;">�����:</div><input name="_databaseUsername" id="_databaseUsername" value='' type="text" style="width: 190px;"></td>
                      </tr>
					</table>
                    <table class="adn">
                      <tr>
					    <td height="8" colspan="2"></td>
					  </tr>
					  <tr>
                        <td align="left" colspan="2"><div align="left" style="padding-bottom: 3px;">������:</div><input type="text" name="_databasePassword" id="_databasePassword" value=''  style="width: 190px;"></td>
                        <td align="left"><div align="left" style="padding-bottom: 3px;">�������� ��:</div><input name="_databaseName" id="_databaseName" value='' type="text" style="width: 190px;"></td>
                      </tr>
					  <tr>
					    <td height="8" colspan="3"></td>
					  </tr>
                    </table>
                    <table class="adn">
                      <tr>
                        <td><div align="left" style="padding-bottom: 3px;">����� �������� �����-��:</div><input name="adminLogin" id="adminLogin" type="text" value="admin" style="width: 190px;"></td>
                        <td><div align="left" style="padding-bottom: 3px;">������ �������� �����-��:</div><input name="adminPassword" id="adminPassword" type="text" value="1234" style="width: 190px;"></td>
                      </tr>
                    </table>
				<br><div align="left"><input type=hidden name='next' value=1><input type=hidden name='connect' value="yes"><input type=submit value="��������� ���������"></div>
                  </td>
                </tr>
		      </table>
			</td>
	      </tr>
		</table>
		</div>
        <script type="text/javascript">
        randomPass();
        </script>
      </form>
    </td>
  </tr>
  <tr>
    <td align="left"><br><br><div id="dataload" align=left></div></td>
  </tr>
</table><br><br>
	<?php
    echo "</body></html>";
}
else {
    print "on";
}
?>