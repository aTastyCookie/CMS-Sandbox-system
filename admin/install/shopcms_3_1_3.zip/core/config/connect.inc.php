<?php
//database connection settings
define('DBMS', 'mysql');                       // database system
define('DB_HOST', 'localhost');                // database host
define('DB_USER', '');        // username
define('DB_PASS', '');        // password
define('DB_NAME', '');        // database name
define('DB_PRFX', '');        // database prefix

// include table name file
include('core/config/tables.inc.php');
?>
