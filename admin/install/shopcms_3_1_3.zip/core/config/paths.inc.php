<?php
define( 'DATABASE_STRUCTURE_XML_PATH',  'core/config/database_structure.xml' );
define( 'RESULT_XML_PATH', 'core/config/result.xml' );
define( 'TABLES_INC_PHP_PATH', 'core/config/tables.inc.php' );
define( 'CONNECT_INC_PHP_PATH', 'core/config/connect.inc.php' );
?>